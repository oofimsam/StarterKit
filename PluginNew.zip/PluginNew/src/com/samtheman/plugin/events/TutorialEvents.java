package com.samtheman.plugin.events;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;

public class TutorialEvents implements Listener {

    @EventHandler
    public static void onPlayerJoin(PlayerJoinEvent event) {
        Location loc = Bukkit.getWorld("world").getSpawnLocation();
                loc.setY(75);
                loc.setX(0.500);
                loc.setZ(0.500);
                        loc.setYaw(-94);
        loc.setPitch(-4);


        Player player = event.getPlayer();
        boolean hasPlayed = player.hasPlayedBefore();
        if (hasPlayed) {
            player.sendMessage(ChatColor.GREEN + "Welcome back!");
        } else {
            player.sendMessage(ChatColor.LIGHT_PURPLE + "welcome to the server :)");
            player.teleport(loc);
            player.giveExpLevels(10);
            player.sendMessage(ChatColor.RED + "enjoy your free 10 XP levels!");
            player.getInventory().setBoots(new ItemStack(Material.LEATHER_BOOTS));
            player.getInventory().setHelmet(new ItemStack(Material.LEATHER_HELMET));
            player.getInventory().setLeggings(new ItemStack(Material.LEATHER_LEGGINGS));
            player.getInventory().setChestplate(new ItemStack(Material.LEATHER_CHESTPLATE));
            player.getInventory().addItem(new ItemStack(Material.STONE_SWORD, 1));
            player.getInventory().addItem(new ItemStack(Material.STONE_AXE, 1));
            player.getInventory().addItem(new ItemStack(Material.STONE_PICKAXE, 1));
            player.getInventory().addItem(new ItemStack(Material.STONE_SHOVEL, 1));
            player.sendMessage(ChatColor.BLACK + "Enjoy your free starter kit!");
        }
    }


}
